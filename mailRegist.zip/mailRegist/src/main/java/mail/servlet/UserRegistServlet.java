package mail.servlet;

import java.io.IOException;
import java.sql.Timestamp;
import java.util.Date;
import java.util.Timer;
import java.util.TimerTask;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import mail.bean.User;
import mail.server.UserServer;
import mail.server.impl.UserServerImpl;
import mail.utils.UUID64;
/**
 * 用户注册的servlet
 * @author Administrator
 *
 */
public class UserRegistServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("UTF-8");
		String username=request.getParameter("username");
		String nickname=request.getParameter("nickname");
		String password=request.getParameter("password");
		String email=request.getParameter("email");
		Integer state=0;
		String statecode=UUID64.getUUID();
		//特别注意，这里要处理一下时间
		Timestamp createTime=new Timestamp(new Date().getTime());
		final User user=new User();
		user.setUsername(username);
		user.setNickname(nickname);
		user.setPassword(password);
		user.setEmail(email);
		user.setState(state);
		user.setStatecode(statecode);
		user.setCreateTime(createTime);
		final UserServer userServer=new UserServerImpl();
		try {
			userServer.regist(user); //注册用户
			//设置在用户两小时内没有激活操作，则删除用户在数据库中的信息
			Timer timer=new Timer();
			timer.schedule(new TimerTask() {
				public void run() {
					userServer.deleteUnactiveUser(user);
				}
			},1000*60*60*2);  //两小时后没有激活，则会运行上面的run方法
		} catch (Exception e) {
			e.printStackTrace();
		}
		request.setAttribute("regist_message","账号注册成功！请在2小时内到邮箱进行激活操作！");
		request.getRequestDispatcher("/WEB-INF/reg_msg.jsp").forward(request, response);  //转发
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}

}
