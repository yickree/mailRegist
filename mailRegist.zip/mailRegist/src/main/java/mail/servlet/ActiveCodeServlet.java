package mail.servlet;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import mail.bean.User;
import mail.server.UserServer;
import mail.server.impl.UserServerImpl;

/**
 * Servlet implementation class ActiveCodeServlet
 */
public class ActiveCodeServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		UserServer userServer=new UserServerImpl();
		String statecode=request.getParameter("statecode");
		User user=userServer.getUserByStateCode(statecode);
		if(user==null) {
			request.setAttribute("regist_message","用户不存在，激活失败！");
			request.getRequestDispatcher("/WEB-INF/reg_msg.jsp").forward(request, response);
			return;
		}
		int res=userServer.activeCode(user);  //激活用户操作方法
		if(res!=1) {
			request.setAttribute("regist_message","激活失败，请重新注册账号！");
		}else {
			request.setAttribute("regist_message","激活成功，请重登入账号！");
		}
		request.getRequestDispatcher("/WEB-INF/reg_msg.jsp").forward(request, response);
	}
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}

}
