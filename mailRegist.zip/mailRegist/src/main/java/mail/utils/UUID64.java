package mail.utils;

import java.util.UUID;

public class UUID64 {
	/**
	 * 用于返回一个64位只含数字和大小写字母的随机字符串，多用于验证用户的合法激活账号
	 * @return
	 */
	public static String getUUID() {
		return UUID.randomUUID().toString().replaceAll("-","")+UUID.randomUUID().toString().replaceAll("-","");
	}
}
