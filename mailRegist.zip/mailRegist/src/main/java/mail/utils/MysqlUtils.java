package mail.utils;
/**
 * 用于数据连接的工具类
 * @author Administrator
 *
 */

import java.io.IOException;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.Properties;

import org.apache.commons.dbcp.BasicDataSource;


public class MysqlUtils {
	private static BasicDataSource bds;
	static {
		Properties config=new Properties();
		InputStream inStream=MysqlUtils.class.getClassLoader().getResourceAsStream("dbConfig.properties");
		try {
			config.load(inStream);
		} catch (IOException e) {
			e.printStackTrace();
		}
		String driver=config.getProperty("jdbc-driver");
		String url=config.getProperty("jdbc-url");
		String username=config.getProperty("jdbc-username");
		String password=config.getProperty("jdbc-password");
		String init=config.getProperty("dbcp-init");
		String maxActive=config.getProperty("dbcp-maxactive");
		bds=new BasicDataSource();
		bds.setDriverClassName(driver);
		bds.setUrl(url);
		bds.setUsername(username);
		bds.setPassword(password);
		bds.setInitialSize(Integer.parseInt(init));
		bds.setMaxActive(Integer.parseInt(maxActive));
	}
	
	public static Connection getConnection(){
		Connection conn=null;
		try {
			conn=bds.getConnection();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return conn;
	}
	public static void closeConnection(Connection conn) {
		try {
			if(conn!=null) {
				conn.setAutoCommit(true);  //开启自动提交状态，防止用户更改后没有还原，默认为true
				conn.close();
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
	public static void rollback(Connection conn) {  //回滚
		try {
			if(conn!=null) {
				conn.rollback();
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
	public static void commit(Connection conn) {  //提交
		try {
			if(conn!=null) {
				conn.commit();
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
}
