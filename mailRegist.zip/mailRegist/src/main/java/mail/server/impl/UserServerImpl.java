package mail.server.impl;

import mail.bean.User;
import mail.dao.UserDao;
import mail.dao.impl.UserDaoImpl;
import mail.server.UserServer;
import mail.utils.MailUtils;

public class UserServerImpl implements UserServer {
	/**
	 * 用户注册
	 */
	@Override
	public void regist(User user) throws Exception {
		//用户注册
		UserDao userDao=new UserDaoImpl();
		userDao.insertUser(user);
		//发送激活邮件
		MailUtils.sendMail(user.getEmail(),user.getStatecode(),user.getUsername());
	}

	/**
	 * 账户激活操作
	 */
	@Override
	public Integer activeCode(User user) {
		UserDao userDao=new UserDaoImpl();
		user.setState(1);  //表示用户账号已经激活了
		user.setStatecode("nodata");  //nodata表示该账号没有激活码，一般对应这state=1的状态
		userDao.updateUser(user);
		return userDao.updateUser(user);
	}

	/**
	 * 根据用户激活码找用户信息
	 */
	@Override
	public User getUserByStateCode(String statecode) {
		UserDao userDao=new UserDaoImpl();
		return userDao.findUserByStateCode(statecode);
	}

	/**
	 * 删除没有注册的用户
	 */
	@Override
	public void deleteUnactiveUser(User user) {
		UserDao userDao=new UserDaoImpl();
		userDao.deleteUser(user);
	}

}
