package mail.server;


import mail.bean.User;

public interface UserServer {
	/**
	 * 用户注册
	 */
	void regist(User user) throws Exception ;
	/**
	 * 账户激活操作
	 */
	Integer activeCode(User user);
	/**
	 * 根据用户的激活码寻找到用户信息
	 * @param statecode
	 * @return
	 */
	User getUserByStateCode(String statecode);
	/**
	 * 删除没有激活的的用户
	 * @param user
	 */
	void deleteUnactiveUser(User user);
}
