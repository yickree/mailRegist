package mail.dao;

import mail.bean.User;

public interface UserDao {
	/**
	 * 插入用户数据
	 * @param user
	 */
	void insertUser(User user);
	/**
	 * 更改用户数据
	 * @param user
	 * @return
	 */
	Integer updateUser(User user);
	/**
	 * 根据用户用户激活码查找用户信息
	 * @param statecode
	 * @return
	 */
	User findUserByStateCode(String statecode);
	/**
	 * 删除某个用户
	 * @param user
	 */
	void deleteUser(User user);
}
