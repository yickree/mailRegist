package mail.dao.impl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Timestamp;

import mail.bean.User;
import mail.dao.UserDao;
import mail.utils.MysqlUtils;

public class UserDaoImpl implements UserDao {
	@Override
	public void insertUser(User user) {
		Connection conn=MysqlUtils.getConnection();
		try {
			String sql="insert into t_user(id,username,nickname,password,email,state,statecode,"
					+ "create_time) values(null,?,?,?,?,?,?,?)";
			PreparedStatement ps=conn.prepareStatement(sql,new String[] {"id"});
			ps.setString(1,user.getUsername());
			ps.setString(2,user.getNickname());
			ps.setString(3,user.getPassword());
			ps.setString(4,user.getEmail());
			ps.setInt(5,user.getState());
			ps.setString(6,user.getStatecode());
			ps.setTimestamp(7,(Timestamp)user.getCreateTime());
			ps.executeUpdate();
			ResultSet res=ps.getGeneratedKeys();
			while(res.next()){
				user.setId(res.getInt(1));
			}
			res.close();
			ps.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		catch(Exception e) {
			e.printStackTrace();
		}finally {
			MysqlUtils.closeConnection(conn);
		}
	}

	@Override
	public Integer updateUser(User user) {
		Connection conn=MysqlUtils.getConnection();
		//此处省略用户创建时间，这个一般不用修改
		String sql="update t_user set username=?,nickname=?,password=?,email=?,state=?,statecode=? where id=?";
		try {
			PreparedStatement ps=conn.prepareStatement(sql);
			ps.setString(1,user.getUsername());
			ps.setString(2,user.getNickname());
			ps.setString(3,user.getPassword());
			ps.setString(4,user.getEmail());
			ps.setInt(5,user.getState());
			ps.setString(6,user.getStatecode());
			ps.setInt(7,user.getId());
			ps.executeUpdate();
			ps.close();
			return 1;  //表示修改成功
		} catch (SQLException e) {
			e.printStackTrace();
		}finally {
			MysqlUtils.closeConnection(conn);
		}
		return 0;  //表示修改失败
	}

	@Override
	public User findUserByStateCode(String statecode) {
		Connection conn=MysqlUtils.getConnection();
		String sql="select id,username,nickname,password,email,state,statecode,create_time as"
				+ " createTime from t_user where statecode=?";
		User user=null;
		try {
			PreparedStatement ps=conn.prepareStatement(sql);
			ps.setString(1,statecode);
			ResultSet res=ps.executeQuery();
			if(res.next()) {
				user=new User();
				user.setId(res.getInt("id"));
				user.setUsername(res.getString("username"));
				user.setNickname(res.getString("nickname"));
				user.setPassword(res.getString("password"));
				user.setEmail(res.getString("email"));
				user.setState(res.getInt("state"));
				user.setStatecode(res.getString("statecode"));
				user.setCreateTime(res.getTimestamp("createTime"));
				res.close();
				ps.close();
				return user;
			}
			res.close();
			ps.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}finally {
			MysqlUtils.closeConnection(conn);
		}
		return user;
	}

	@Override
	public void deleteUser(User user) {
		Connection conn=MysqlUtils.getConnection();
		String sql="delete from t_user where id="+user.getId()+" and state=0 and statecode!='nodata'";
		try {
			Statement stat=conn.createStatement();
			if(stat.executeUpdate(sql)<1) {
				System.out.println("没有删除操作！");
			}else {
				System.out.println("删除成功！");
			}
			stat.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}finally {
			MysqlUtils.closeConnection(conn);
		}
	}

}
