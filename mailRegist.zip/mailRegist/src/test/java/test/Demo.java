package test;
import java.util.Date;
import java.sql.Timestamp;
import java.util.UUID;

import org.junit.Test;
public class Demo {
	@Test
	public void UUID() {
		UUID uuid=UUID.randomUUID();
		System.out.println(uuid);
		String uid=uuid.toString();
		System.out.println(uid);
		String id=uid.replaceAll("-","");
		System.out.println(id);
		Date date=new Timestamp(System.currentTimeMillis());
		System.out.println(date);
		Date date2=new Timestamp(new Date().getTime());
		System.out.println(date2);
	}
}
